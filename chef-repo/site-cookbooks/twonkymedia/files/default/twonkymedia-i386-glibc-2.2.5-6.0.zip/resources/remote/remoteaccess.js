var beamRunning = false;

function isBeamRunning()
{
	return beamRunning;
}

function onBeamLaunch()
{
	beamRunning = true;
	document.getElementById('remoteaccess').reportBeamLaunch();
}
function onBeamClose()
{
	beamRunning = false;
	clearBeamList();
}

function addBeamListItem(id, src)
{
	var beamList =  document.getElementById('beamList');
	
	if(!beamList)
	{
		var beamListDiv = document.createElement('div');
		beamListDiv.setAttribute('id', 'beamList');
		document.body.appendChild(beamListDiv);
	}
	
	var itemDiv = document.createElement('div');
	itemDiv.setAttribute('id', id);
	itemDiv.setAttribute('src', src);
	beamList.appendChild(itemDiv);
}

function clearBeamList()
{
	var beamList = document.getElementById('beamList');
	
	if(beamList)
		beamList.innerHTML = '';
}

function onBeamItemSelect(args)
{
	/*alert("onBeamItemSelect called with args:\n\n" + args);*/
}

function onBeamItemUnselect(args)
{
	/*alert("onBeamItemUnselect called with args:\n\n" + args);*/
}

var BrowserDetect = 
{
	browserIdentity: 'unknown',
	browserVersion: 'unknown',
	osIdentity: 'unknown',
	redirect: null,
	
	init: function () 
	{
		//
		// Get browser identity
		//
		this.browserIdentity = this.getIdentity(this.browserData) ||
							   'unknown';
		
		//
		//	Get browser version
		//
		this.browserVersion = this.getVersion(navigator.userAgent) ||
							  this.getVersion(navigator.appVersion) ||
							  'unknown';
		
		//
		// Get Operating System identity
		//				  
		this.osIdentity = this.getIdentity(this.osData) ||
						  'unknown';
		
		//
		// Get redirect data
		//
		this.redirect = this.getRedirect(this.osData, this.osIdentity) || 
						this.getRedirect(this.browserData, this.browserIdentity) || 
						false;
	},
	
	getIdentity: function (data) 
	{
		for (var ii = 0; ii < data.length; ii++)	
		{
			var dataString = data[ii].string;
			var dataProp = data[ii].prop;
			this.versionSearchString = data[ii].versionSearch || data[ii].identity;
			
			if (dataString) 
			{
				if (dataString.indexOf(data[ii].subString) != -1)
					return data[ii].identity;
			}
			else if (dataProp)
			{
				return data[ii].identity;
			}
		}
		
		return null;
	},
	
	getVersion: function (dataString) 
	{
		var index = dataString.indexOf(this.versionSearchString);
		
		if (index == -1) 
			return null;
			
		return parseFloat(dataString.substring(index + this.versionSearchString.length + 1));
	},
	
	getRedirect: function(data, id)
	{
		for (var ii = 0; ii < data.length; ii++)	
		{
			if (id == data[ii].identity && data[ii].redirect)
			{
				return data[ii].redirect;
			}
		}
		
		return null;
	},
	
	isDesktop: function()
	{
		return (this.osIdentity == 'Windows' || this.osIdentity == 'Mac' || this.osIdentity == 'Linux')
	},
	
	isIE: function()
	{
		return ('Internet Explorer' == this.browserIdentity);
	},
	
	browserData: [
		{ 	// Android
			string: navigator.userAgent,
			subString: 'Android',
			identity: 'Android',
			redirect: '/webbrowse-n95'
		},
		{	// Camino
			string: navigator.vendor,
			subString: 'Camino',
			identity: 'Camino'
		},
		{	// Chrome
			string: navigator.userAgent,
			subString: 'Chrome',
			identity: 'Chrome'
		},
		{	// Firefox
			string: navigator.userAgent,
			subString: 'Firefox',
			identity: 'Firefox'
		},
		{	// iCab
			string: navigator.vendor,
			subString: 'iCab',
			identity: 'iCab'
		},
		{	// Internet Explorer
			string: navigator.userAgent,
			subString: 'MSIE',
			identity: 'Internet Explorer',
			versionSearch: 'MSIE'
		},
		{	// KDE
			string: navigator.vendor,
			subString: 'KDE',
			identity: 'Konqueror'
		},
		{	// Mozilla
			string: navigator.userAgent,
			subString: 'Gecko',
			identity: 'Mozilla',
			versionSearch: 'rv'
		},
		{ 	// Netscape (4-)
			string: navigator.userAgent,
			subString: 'Mozilla',
			identity: 'Netscape',
			versionSearch: 'Mozilla'
		},
		{	// Netscape (6+)
			string: navigator.userAgent,
			subString: 'Netscape',
			identity: 'Netscape'
		},
		{ 	// Nokia N95
			string: navigator.userAgent,
			subString: 'NokiaN95',
			identity: 'Nokia N95',
			redirect: '/webbrowse-n95'
		},
		{ 	// OmniWeb
			string: navigator.userAgent,
			subString: 'OmniWeb',
			versionSearch: 'OmniWeb/',
			identity: 'OmniWeb'
		},
		{	// Opera
			prop: window.opera,
			identity: 'Opera'
		},
		{	// Safari
			string: navigator.vendor,
			subString: 'Apple',
			identity: 'Safari',
			versionSearch: 'Version'
		}
	],
	
	osData: [
		{	// iPhone
			string: navigator.userAgent,
			subString: 'iPhone',
			identity: 'iPhone/iPod',
			redirect: '/webbrowse-e61'
	    },
		{	// Linux
			string: navigator.platform,
			subString: 'Linux',
			identity: 'Linux'
		},
		{	// Mac
			string: navigator.platform,
			subString: 'Mac',
			identity: 'Mac'
		},
		{	// Windows
			string: navigator.platform,
			subString: 'Win',
			identity: 'Windows'
		}
	]

};
BrowserDetect.init();
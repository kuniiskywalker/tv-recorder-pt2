#ifndef _MKPATH_H_
#define _MKPATH_H_

int mkpath(const char *path, mode_t mode);

#endif
